#include <iostream>
#include <cstddef>
#include "Quest.h"
using namespace std;

Quest::Quest(string x, string y, QuestState z) {
	name = x;
	description = y;
	state = z;
}

void Quest::start() {
	cout << name << " Started\n";
	state = Started;
}

void Quest::complete() {
	cout << name << " Finished\n";
	state = Finished;
}

void Quest::printStatus() {
	cout << "Quest Name: " << name << "\nDescription: " << description << "\nState: " << state << "\n";
}

void FetchQuest::start() {
	cout << name << " Started\n";
	state = Started;
}

void FetchQuest::complete() {
	cout << name << " Finished\n";
	state = Finished;
}

void TalkQuest::start() {
	cout << name << " Started\n";
	state = Started;
}

void TalkQuest::complete() {
	cout << name << " Finished\n";
	state = Finished;
}