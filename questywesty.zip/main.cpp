#include <iostream>
#include <cstddef>
#include "Quest.h"
using namespace std;

int main() {
	int i;
	Quest a("Test", "Test desc", NotStarted);
	FetchQuest b("Fetch", "Fetch desc", NotStarted);
	TalkQuest c("Talk", "Talk desc", NotStarted);

	Quest* quests[3];
	quests[0] = &a;
	quests[1] = &b;
	quests[2] = &c;

	for (i = 0; i < 3; i++) {
		quests[i]->printStatus();
		quests[i]->start();
		quests[i]->printStatus();
		quests[i]->complete();
		quests[i]->printStatus();
	}
}