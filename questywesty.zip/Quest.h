#pragma once
#include <iostream>
#include <cstddef>

enum QuestState {NotStarted, Started, Finished};

class Quest {
	protected:
		std::string name;
		std::string description;
		QuestState state;
	public:
		Quest(std::string x, std::string y, QuestState z);
		virtual void start();
		virtual void complete();
		void printStatus();
};

class FetchQuest : public Quest {
	public:
		FetchQuest(std::string x, std::string y, QuestState z) : Quest(x, y, z) {}
		void start() override;
		void complete() override;
};

class TalkQuest : public Quest {
	public:
		TalkQuest(std::string x, std::string y, QuestState z) : Quest(x, y, z) {}
		void start() override;
		void complete() override;
};
